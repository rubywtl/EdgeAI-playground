# ******************************************************************************
#  Copyright (c) 2021-2022. Kneron Inc. All rights reserved.                   *
# ******************************************************************************
from ..KPWrapper import KPWrapper as KPCoreWrapper
from .WrapperBase import WrapperBase
from .LibLoaderBase import LibLoaderBase
import abc


class AppWrapperBase(WrapperBase):
    def __init__(self, lib_loader: LibLoaderBase):
        KPCoreWrapper()
        super(AppWrapperBase, self).__init__(lib_loader=lib_loader)

    @abc.abstractmethod
    def _init_sdk_functions(self):
        pass
